<?php

/**
* 
*/
class home extends base
{
	
	function __construct()
	{
		
	}
	function index()
	{
     	 V('mvc');
     
	}
	function test()
	{
		dump(Request::server());
	}
	function hello2()
	{

    	
	}



}

