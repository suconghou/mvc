<?php
/**
* 布局模板,数据排版
* 提供静态方法
* 几大组件
* 
*
*/
class layout
{
	
	function __construct()
	{
		
	}
	function init()
	{

	}
	static function header()
	{
		echo 'header';
	}
	static function menu()
	{

	}
	static function lists()
	{

	}
	static function body()
	{

	}
	static function sidebar()
	{

	}
	static function footer()
	{

	}
}